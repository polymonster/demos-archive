// MainToolBar.cpp: implementation of the CMainToolBar class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ToolBar.h"
#include "MainToolBar.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMainToolBar::CMainToolBar()
{

}

CMainToolBar::~CMainToolBar()
{

}
