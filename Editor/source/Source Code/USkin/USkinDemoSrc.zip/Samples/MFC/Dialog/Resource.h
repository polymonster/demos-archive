//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Dialog.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FORMVIEW                    101
#define IDD_PAGE1                       101
#define IDD_DIALOG_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     130
#define IDC_CHECK1                      1000
#define IDC_CHECK2                      1001
#define IDC_RADIO1                      1002
#define IDC_RADIO2                      1003
#define IDC_COMBO1                      1004
#define IDC_COMBO2                      1005
#define IDC_COMBO3                      1006
#define IDC_COMBO4                      1007
#define IDC_EDIT1                       1008
#define IDC_EDIT2                       1009
#define IDC_EDIT3                       1010
#define IDC_SPIN1                       1011
#define IDC_BUTTON1                     1012
#define IDC_BUTTON2                     1013
#define IDC_TAB1                        1013
#define IDC_BUTTON3                     1014
#define IDC_BUTTON4                     1015
#define IDC_BUTTON5                     1016
#define IDC_SLIDER2                     1018
#define IDC_SLIDER3                     1019
#define IDC_PROGRESS1                   1020
#define IDC_PROGRESS2                   1021
#define IDC_SCROLLBAR1                  1022
#define IDC_LIST1                       1023
#define IDC_IPADDRESS1                  1024
#define IDC_HOTKEY1                     1025
#define IDC_DATETIMEPICKER1             1026
#define IDC_MONTHCALENDAR1              1027
#define IDC_BUTTON6                     1028
#define IDC_BUTTON7                     1029
#define ID_APP_ABOUT2                   32771
#define ID_ABOUTSKINFILE                32774
#define ID_COLORTHEME                   32775
#define ID_MENUITEM32776                32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
