//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SDI.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_SDITYPE                     129
#define ID_COLORTHEME                   32773
#define ID_ABOUTSKINFILE                32774
#define ID_TEST1                        32778
#define ID_TEST2                        32779
#define ID_TEST3                        32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
